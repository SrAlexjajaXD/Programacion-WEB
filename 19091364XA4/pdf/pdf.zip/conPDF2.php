<?php
include_once('PDF.php');
require "qr/qr.php";

function cUTF($cadena){
  return  iconv('utf-8', 'ISO-8859-1',$cadena);
     session_start();
}

 session_start();
   if (isset($_SESSION['usuario'])){
   }
   else
     header ("Location: index.php");

   $Date= date('d/F/Y ',time());
   $Time=date('h:i:s a',time());
   qr_encode("".$_SESSION['usuario']."\n".$_SESSION['nombre']."\nCreado el ".$Date." a las ".$Time."\n","estaciones");
/*
function tabla($cursor){
    echo "<table border=1>";
    echo "<tr>";
    foreach($cursor[0] as $key=>$registro){
      echo "<th>".$key."</th>";  
    }
    echo "</tr>";
    foreach($cursor as $registro){
        echo "<tr>";
        foreach($registro as $key=>$campo){
            echo "<td>";
            echo "$campo";
            echo "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
}
*/

$pdf = new PDF("P","mm","Letter");
 
$pdf->AddPage();

$pdf->SetFont('Arial','B',16);

$anchoPag=$pdf->GetPageWidth();  // Width of Current Page
$altoPag=$pdf->GetPageHeight(); // Height of Current Page

$titulo1=cUTF('** Consulta a la base de datos **');
$tam1=$pdf->GetStringWidth($titulo1);
$pdf->SetXY(($anchoPag-$tam1)/2,45);
$pdf->Cell($tam1, 10, $titulo1); // centrando texto

$pdf->SetFont('Arial','I',14);
$titulo2=cUTF(''); 
$tam2=$pdf->GetStringWidth($titulo2);
$pdf->SetXY(($anchoPag-$tam2)/2,55);
$pdf->Cell($tam2, 10, $titulo2); // centrando texto

$miCabecera = array('Modelo','Marca', 'Tipo', 'Precio');
 
$pass = "123";
$usuario = "sharky";
$nombreBaseDeDatos = "NewBase";
# Puede ser 127.0.0.1 o el nombre de tu equipo; o la IP de un servidor remoto
$rutaServidor = "127.0.0.1";
$puerto = "5432";

try {
    $base_de_datos = new PDO("pgsql:host=$rutaServidor;port=$puerto;dbname=$nombreBaseDeDatos", $usuario, $pass);
    $base_de_datos->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sentencia = $base_de_datos->query("select * from motos");
    $motos = $sentencia->fetchAll(PDO::FETCH_OBJ);
} catch (Exception $e) {
    echo "Ocurrió un error con la base de datos: " . $e->getMessage();
}

// Genera una tabla con cabecera y renglones (color de renglón alternado)
$pdf->tablaHorizontal($miCabecera,        // cadenas para cabecera
                      $motos ,         // resultado de la consulta
                      ($anchoPag-45*4)/2, // Posición X 45*4
                                          // (ancho columna)*(número de columna$
                      75,                 // Posición Y de la tabla
                      45,                 // Ancho de columna
                      7,                  // Alto de renglón
                      "FF0000",           // Color fondo cabecera
                      "FFFFFF",           // Color texto cabecera
                      "FFDDDD"            // Color fondo renglón alternado
                     );


//         Mensaje o texto a codificar                                        Imagen
$pdf->Image('estaciones.png',165,229,40,40,'PNG','');
$pdf->Output(""); //Salida al navegador 

?>


